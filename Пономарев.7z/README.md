# MPEI-Empire

This is the program about mathematical model 'politic-economy' which build on original model of
Puasson's social system and Passionary theory of Ethnogenesys by N.Gumilev.
